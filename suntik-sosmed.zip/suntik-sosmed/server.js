const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/orders", (req, res) => {
  const { service, quantity, contact } = req.body;
  if (!service || !quantity || !contact) {
    return res.status(400).json({ error: "Lengkapi semua data!" });
  }

  const order = {
    id: Date.now(),
    service,
    quantity,
    contact,
    status: "Menunggu Pembayaran",
    time: new Date().toISOString()
  };

  const filePath = path.join(__dirname, "orders.json");
  let orders = [];

  if (fs.existsSync(filePath)) {
    orders = JSON.parse(fs.readFileSync(filePath));
  }

  orders.push(order);
  fs.writeFileSync(filePath, JSON.stringify(orders, null, 2));

  res.json({ message: "Order berhasil", order });
});

app.listen(PORT, () => {
  console.log(`Server jalan di http://localhost:${PORT}`);
});